"""THE single source of the Pages workflow, job and step display names (SPEC §5.9).

The jobs API reports a job of a called (reusable) workflow as ``"<caller job name> / <callee job
name>"``; caller-owned jobs keep their bare name. Consumers must compare names with exact equality
through :func:`find_job`; ``endswith``/``startswith`` matching is forbidden. Producer-side names are
config (``source.handoff_job/handoff_step``, ``families[].producer.job/step``), not constants here.
"""

from __future__ import annotations

import string
from collections.abc import Mapping, Sequence
from typing import Any

from mod_base.errors import MbError
from mod_base.model import grammar

#: Display name and path of the managed caller workflow (kept: QS feature-coverage depends on both).
PAGES_WORKFLOW_NAME = "Project site"
PAGES_WORKFLOW_PATH = ".github/workflows/pages.yml"
PAGES_EVENTS = frozenset({"workflow_dispatch", "schedule"})
PAGES_CRON = "43 * * * *"
OPERATIONS = ("manual", "deploy", "family", "rotate")
#: The ``operation`` the caller passes to ``publish.yml`` (a schedule becomes ``recovery``).
PUBLISH_OPERATIONS = ("recovery", "manual", "deploy", "family")
PUBLICATION_LOCK = "mod-base-pages-publication"
ROTATION_LOCK = "mod-base-pages-rotation"

#: Callee workflow id -> its path inside the kit repository.
CALLEE_WORKFLOWS = {
    "publish": ".github/workflows/publish.yml",
    "finalize": ".github/workflows/finalize.yml",
    "rotate": ".github/workflows/rotate.yml",
}

CALLER = {
    "verify_kit": "Verify pinned mod-base",
    "publish": "Publish",
    "deploy": "Deploy GitHub Pages",
    "finalize": "Finalize",
    "request_rotation": "Request post-success evidence rotation",
    "rotate": "Rotate",
}
CALLEE = {
    "publish": {
        "admit": "Admit publication",
        "collect": "Collect {key}",
        "family": "Collect {family} {key}",
        "build": "Build atomic static site",
    },
    "finalize": {
        "refresh": "Refresh evidence cache for {key}",
        "refresh_family": "Refresh {family} cache for {key}",
    },
    "rotate": {"rotate": "Rotate the authenticated successful generation"},
}
STEPS = {
    "select": "Select the newest authenticated evidence",
    "family_select": "Select the newest authenticated family generation",
    "cache_upload": "Roll the protected evidence cache forward",
    "family_cache_upload": "Roll the protected family cache forward",
    "baseline_upload": "Retain the complete compact generation for feature evidence reuse",
}

#: Placeholder -> the ``${{ matrix.* }}`` expression the callee YAML uses for it.
MATRIX_EXPRESSIONS = {"key": "${{ matrix.key }}", "family": "${{ matrix.family }}"}


def _placeholders(template: str) -> set[str]:
    return {field for _, field, _, _ in string.Formatter().parse(template) if field is not None}


def _validate_fields(template: str, fields: Mapping[str, Any]) -> None:
    wanted = _placeholders(template)
    if set(fields) != wanted:
        raise MbError(f"job name {template!r} needs exactly the fields {sorted(wanted)}")
    if "key" in fields:
        grammar.require_key(fields["key"])
    if "family" in fields:
        grammar.require_family(fields["family"])


def caller_job_name(key: str) -> str:
    """Return the bare display name of a caller-owned job, e.g. ``"Deploy GitHub Pages"``."""

    try:
        return CALLER[key]
    except KeyError:
        raise MbError(f"unknown caller job {key!r}") from None


def callee_job_name(workflow: str, job: str, **fields: str) -> str:
    """Return the callee's own ``name:`` value with its placeholders filled (no caller prefix)."""

    try:
        template = CALLEE[workflow][job]
    except KeyError:
        raise MbError(f"unknown callee job {workflow!r}/{job!r}") from None
    _validate_fields(template, fields)
    return template.format(**fields)


def api_job_name(workflow: str, job: str, **fields: str) -> str:
    """Return the name the jobs API reports for a callee job, e.g. ``"Publish / Collect mc1.20.1"``."""

    return f"{CALLER[workflow]} / {callee_job_name(workflow, job, **fields)}"


def workflow_template_name(workflow: str, job: str) -> str:
    """Return the callee job ``name:`` exactly as written in its YAML (``${{ matrix.* }}`` form)."""

    try:
        template = CALLEE[workflow][job]
    except KeyError:
        raise MbError(f"unknown callee job {workflow!r}/{job!r}") from None
    result = template
    for field in _placeholders(template):
        result = result.replace("{" + field + "}", MATRIX_EXPRESSIONS[field])
    return result


def unexpanded_api_job_name(workflow: str, job: str) -> str:
    """Return the name the jobs API reports, once, for a matrix callee job that its job-level ``if``
    skipped before its matrix expanded: the caller prefix and the unexpanded YAML template name, e.g.
    ``"Publish / Collect ${{ matrix.family }} ${{ matrix.key }}"`` (Quick Skin
    ``e2e_job_graph.UNEXPANDED_SCENARIO_JOB``). Exact equality only, like every other name."""

    return f"{CALLER[workflow]} / {workflow_template_name(workflow, job)}"


def step_name(key: str) -> str:
    try:
        return STEPS[key]
    except KeyError:
        raise MbError(f"unknown step {key!r}") from None


def find_job(jobs: Sequence[Mapping[str, Any]], name: str, *, run_attempt: int) -> dict[str, Any]:
    """Return the single job named exactly ``name`` in ``run_attempt``.

    Exact equality only; exactly one job in ``jobs`` may carry ``name`` and it must report
    ``run_attempt``. Anything else (no match, several matches, a match from another attempt, a
    malformed record) raises :class:`MbError`. Never ``endswith``/``startswith``.
    """

    if not isinstance(name, str) or not name:
        raise MbError("job name must be a non-empty string")
    if isinstance(run_attempt, bool) or not isinstance(run_attempt, int) or run_attempt <= 0:
        raise MbError("run attempt must be a positive integer")
    if not isinstance(jobs, Sequence) or isinstance(jobs, (str, bytes)):
        raise MbError("jobs must be a list of job records")
    matches: list[Mapping[str, Any]] = []
    for job in jobs:
        if not isinstance(job, Mapping) or not isinstance(job.get("name"), str):
            raise MbError("job record is malformed")
        if job["name"] == name:
            matches.append(job)
    if len(matches) != 1:
        raise MbError(f"expected exactly one job named {name!r}, found {len(matches)}", reason="job-graph")
    job = matches[0]
    attempt = job.get("run_attempt")
    if isinstance(attempt, bool) or attempt != run_attempt:
        raise MbError(f"job {name!r} does not belong to attempt {run_attempt}", reason="job-graph")
    return dict(job)
