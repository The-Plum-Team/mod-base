"""Closed protected Build configuration, distinct from the Pages v1 config.

``scripts/ci/mod-base-build.json`` names the adapter entry points and their hashed import closure,
the candidate files a plan is derived from (the inventory, the scenario contract and up to
``limits.MAX_CI_PLAN_INPUTS`` extra ``plan_inputs``), where a lane's checkout expects the staged
Build, the two required status contexts, the native timeouts and, optionally, the kit system profile
a lane installs before its accounts exist (:func:`system_profile`), the seeds its jobs restore
(:func:`seed_key_files`) and the paths a pull request may change only with an approver's decision on
its exact head (:func:`admission`): an approver is a user with the association listed for them or,
since v1.6.0, every active member of the organization that owns the repository
(:func:`admission_organization`). :func:`validate_build_config` is the
pure schema; :func:`load_build_config` reads the file from the protected checkout the prologue
verified and requires every listed source there to have its configured hash, so its result is the
complete protected adapter that planning hashes into the policy digest. It also records the mod's
own control files (:data:`CONTROL_PATHS`), which the same digest covers. The optional
``runtime_selection`` (:func:`runtime_selection`) lets a pull request's packaged lanes run a narrowed
scope.
"""

from __future__ import annotations

import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mod_base import readable_schema_versions
from mod_base.build_ci.activation import ACTIVATION_PATH, GATE_CALLERS
from mod_base.build_ci.adapter import plan_input_name, plan_sources
from mod_base.build_ci.protocol import BUILD_ADAPTER_API, PROFILES, SYSTEM_PROFILES, check_output_paths, repo_path
from mod_base.errors import MbError
from mod_base.io.secure_json import loads
from mod_base.model import grammar as g
from mod_base.model import limits as lim
from mod_base.model.canonical import read_regular_file, sha256_hex
from mod_base.model.validators import Const, Int, List, Obj, OneOf, Str, check, fail


BUILD_CONFIG_PATH = 'scripts/ci/mod-base-build.json'


class BuildConfigError(MbError):
    """The protected Build configuration or a source it lists cannot be trusted (exit 2)."""

    default_reason = "ci-config"


def _context(value: Any, path: str) -> str:
    """A status context: trimmed printable ASCII, so two contexts cannot differ by a lookalike."""

    Str(max_len=lim.MAX_CI_STATUS_CONTEXT_CHARS, text="display")(value, path)
    if not value.isascii():
        raise fail(path, "must be printable ASCII")
    return value


_FILE = Obj({"path": repo_path, "sha256": Str(g.SHA256, max_len=64)})
_PATH = Obj({"path": repo_path})
#: The kinds of seed a protected config may enable, each by the protected files its key binds.
SEED_KINDS = ("gradle", "runtime")
#: The formats of the kit's input to the ``derive_scope`` hook a protected config may name
#: (``runtime_selection.input``): ``changed-paths-v1`` is the paths the tested merge changes against
#: its base and the base commit's authenticated full packaged evidence (``build_ci.scope``).
SCOPE_INPUTS = ("changed-paths-v1",)
_SEED = Obj({"key_files": List(_PATH, min_items=1, max_items=lim.MAX_CI_SEED_KEY_FILES,
                               unique_by=lambda item: item["path"])})
#: One more candidate file the plan is derived from: the name it is staged under for the protected
#: hooks, next to the inventory and the scenario contract, and its path in the tested tree.
_PLAN_INPUT = Obj({"name": plan_input_name, "path": repo_path})
#: The comment command an approver posts as ``<command> approve <head sha>`` or ``<command> revoke
#: <head sha>``: a slash and a lowercase word, such as ``/controller-upgrade``.
ADMISSION_COMMAND = re.compile(r"^/[a-z][a-z0-9-]{0,62}$")
#: A GitHub login, compared without regard to case as GitHub does.
_LOGIN = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$")
#: The ``author_association`` a listed user's comment must carry: the repository's owner, a member of
#: the organization that owns it, or an invited collaborator. No other association can approve. The
#: association is what GitHub shows the API's caller, so it cannot prove a private membership; an
#: organization entry (:data:`ADMISSION_ROLES`) is proven by the organization's member list instead.
ADMISSION_ASSOCIATIONS = ("COLLABORATOR", "MEMBER", "OWNER")
#: The ``role`` of an organization entry among the approvers: ``member`` is every active member of
#: the organization that owns the repository, its owners included, whatever its membership's
#: visibility. A pending invitation is no membership.
ADMISSION_ROLES = ("member",)
_USER_APPROVER = Obj({"login": Str(_LOGIN, max_len=39), "association": Str(choices=ADMISSION_ASSOCIATIONS)})
_ORGANIZATION_APPROVER = Obj({"organization": Str(_LOGIN, max_len=39), "role": Str(choices=ADMISSION_ROLES)})
_APPROVER = OneOf(_USER_APPROVER, _ORGANIZATION_APPROVER)


def _approver_key(approver: dict[str, Any]) -> tuple[str, str]:
    """What two approvers of one list may not share: a user's login or an organization, by kind,
    without regard to case as GitHub compares them."""

    if "organization" in approver:
        return "organization", approver["organization"].casefold()
    return "user", approver["login"].casefold()


_ADMISSION = Obj({
    "protected_paths": List(repo_path, min_items=1, max_items=lim.MAX_CI_ADMISSION_PATHS, sorted_values=True),
    "command": Str(ADMISSION_COMMAND, max_len=63),
    "approvers": List(_APPROVER, min_items=1, max_items=lim.MAX_CI_ADMISSION_APPROVERS, unique_by=_approver_key),
})
_CONFIG = Obj({
    "kind": Const("mod-base.build.config"),
    "schema_version": Int(min(readable_schema_versions("mod-base.build.config")),
                          max(readable_schema_versions("mod-base.build.config"))),
    "repository": Str(g.REPOSITORY, max_len=201),
    "profile": Str(choices=PROFILES),
    "build_adapter_api": Const(BUILD_ADAPTER_API),
    "adapter": Obj({"path": repo_path, "dispatcher": repo_path, "policy": repo_path,
                    "files": List(_FILE, min_items=3, max_items=lim.MAX_CI_ADAPTER_FILES,
                                  unique_by=lambda item: item["path"])}),
    "inventory": _PATH,
    "scenario_contract": _PATH,
    "plan_inputs": List(_PLAN_INPUT, max_items=lim.MAX_CI_PLAN_INPUTS, unique_by=lambda item: item["name"]),
    "bundle": _PATH,
    "contexts": Obj({"build": _context, "packaged": _context}),
    "timeouts": Obj({key: Int(1, lim.MAX_CI_WORKER_TIMEOUT_SECONDS)
                     for key in ("policy_seconds", "target_seconds", "runtime_seconds", "validator_seconds")}),
}, {
    # Optional within schema 1: what a lane job installs on the image before its accounts exist,
    # named, never listed. Absent means none.
    "runtime": Obj({"system_profile": Str(choices=tuple(SYSTEM_PROFILES))}),
    # Optional within schema 1: the seeds a job restores before its candidate runs and a protected
    # job saves after it, each keyed by protected files of the default branch. Absent means none.
    "seeds": Obj({}, {kind: _SEED for kind in SEED_KINDS}),
    # Optional within schema 1: the paths a pull request may change only with an approver's
    # decision on its exact head (:func:`admission`). Absent means no such paths.
    "admission": _ADMISSION,
    # Optional within schema 1: a pull request's packaged lanes may run a narrowed scope that the
    # protected ``derive_scope`` hook selects from the kit's input of this format
    # (``build_ci.scope``). Absent means every lane runs every obligation.
    "runtime_selection": Obj({"input": Str(choices=SCOPE_INPUTS)}),
})


def validate_build_config(document: Any, *, path: str = "$") -> dict[str, Any]:
    """Data only: no matrix/scenario catalog, shell program, runner, permission, package list or
    secret field."""

    _CONFIG(document, path)
    adapter = document["adapter"]
    entries = [adapter[key] for key in ("path", "dispatcher", "policy")]
    check(len(set(entries)) == len(entries), f"{path}.adapter", "adapter, candidate dispatcher and policy are distinct")
    check(all(entry.startswith("scripts/ci/") and entry.endswith(".py") for entry in entries),
          f"{path}.adapter", "entrypoints must be Python files under protected controller roots")
    inventory = [file["path"] for file in adapter["files"]]
    check(inventory == sorted(inventory), f"{path}.adapter.files", "source inventory must be sorted")
    check(set(entries) <= set(inventory), f"{path}.adapter.files", "all fixed entrypoints must be hash-inventoried")
    extra = [item["name"] for item in document["plan_inputs"]]
    check(extra == sorted(extra), f"{path}.plan_inputs", "extra plan inputs must be sorted by name")
    # One tree holds them all: the config, the protected sources, every candidate file a plan is
    # derived from and the directory the Build is staged into. None may alias, contain or replace
    # another.
    check_output_paths([BUILD_CONFIG_PATH, *inventory, *plan_sources(document).values(),
                        document["bundle"]["path"]], path)
    contexts = document["contexts"]
    check(contexts["build"].casefold() != contexts["packaged"].casefold(), f"{path}.contexts",
          "Build and packaged contexts must be distinct")
    if "seeds" in document:
        check(bool(document["seeds"]), f"{path}.seeds", "names at least one seed; omit it for none")
        for kind, seed in document["seeds"].items():
            listed = [item["path"] for item in seed["key_files"]]
            check(listed == sorted(listed), f"{path}.seeds.{kind}.key_files", "must be sorted by path")
    if "admission" in document:
        _check_admission(document["admission"], [BUILD_CONFIG_PATH, *CONTROL_PATHS, *inventory], f"{path}.admission")
        _check_approvers(document["admission"]["approvers"], document["repository"], f"{path}.admission.approvers")
    return document


def protects(protected_paths: list[str] | tuple[str, ...], path: str) -> bool:
    """Whether ``path`` is one of ``protected_paths`` or lies below one of them."""

    return any(path == root or path.startswith(root + "/") for root in protected_paths)


def admission_directories(protected_paths: list[str] | tuple[str, ...]) -> frozenset[str]:
    """The directories that hold a protected path, the root (``""``) included: the trees an
    admission may read on each side of a pull request."""

    return frozenset({""} | {"/".join(parts[:depth]) for parts in (root.split("/") for root in protected_paths)
                             for depth in range(1, len(parts))})


def _check_admission(admission: dict[str, Any], required: list[str], path: str) -> None:
    """A protected-path list in its one canonical form that protects the files deciding how the
    gates execute: the config itself, the activation manifest, the caller workflows the kit can
    manage and every source of the adapter closure. Without them a pull request could remove its
    own admission, which then decides from the default branch only once merged."""

    roots = admission["protected_paths"]
    for index, root in enumerate(roots):
        check(not protects([other for other in roots if other != root], root), f"{path}.protected_paths[{index}]",
              "lies inside another protected path")
    check(len(admission_directories(roots)) <= lim.MAX_CI_ADMISSION_DIRECTORIES, f"{path}.protected_paths",
          f"spread over more than {lim.MAX_CI_ADMISSION_DIRECTORIES} directories")
    missing = sorted(file for file in set(required) if not protects(roots, file))
    check(not missing, f"{path}.protected_paths", f"does not protect {missing[0] if missing else ''}")


def _check_approvers(approvers: list[dict[str, Any]], repository: str, path: str) -> None:
    """At most one organization entry, and only the organization that owns ``repository``: its
    member list is the only one the gate App of the repository is asked for."""

    organizations = [index for index, approver in enumerate(approvers) if "organization" in approver]
    check(len(organizations) <= 1, path, "names more than one organization")
    for index in organizations:
        check(approvers[index]["organization"] == repository.split("/")[0], f"{path}[{index}].organization",
              "must be the organization that owns the repository, spelled as the repository names it")


def admission(document: dict[str, Any]) -> dict[str, Any] | None:
    """The protected admission of a validated config (``protected_paths``, ``command`` and
    ``approvers``), or ``None`` when it names none."""

    return document.get("admission")


def admission_organization(policy: dict[str, Any] | None) -> str | None:
    """The organization whose active members approve under the admission ``policy`` (the
    repository's owner), or ``None`` when ``policy`` is absent or lists users alone."""

    if policy is None:
        return None
    return next((approver["organization"] for approver in policy["approvers"] if "organization" in approver), None)


def system_profile(document: dict[str, Any]) -> str | None:
    """The kit system profile a validated config names (``runtime.system_profile``), or ``None``."""

    return document["runtime"]["system_profile"] if "runtime" in document else None


def runtime_selection(document: dict[str, Any]) -> str | None:
    """The input format of the ``derive_scope`` hook a validated config enables
    (``runtime_selection.input``), or ``None`` when its pull requests always run in full."""

    return document["runtime_selection"]["input"] if "runtime_selection" in document else None


def seed_key_files(document: dict[str, Any], kind: str) -> tuple[str, ...] | None:
    """The protected files that key the seed ``kind`` of a validated config, or ``None`` when the
    config enables no such seed."""

    check(kind in SEED_KINDS, "$.kind", "is not a seed kind")
    seed = document.get("seeds", {}).get(kind)
    return None if seed is None else tuple(item["path"] for item in seed["key_files"])


@dataclass(frozen=True)
class AdapterFile:
    """One source of the protected adapter import closure, as read from the protected checkout."""

    path: str
    sha256: str
    data: bytes


#: What decides, beside the Build config and the adapter closure, how the Build and the packaged E2E
#: of a mod execute: its activation manifest and the Build/E2E caller workflows the kit can manage.
#: A mode that leaves one of them to the mod still makes it a file that runs the mod's gates. The
#: release caller runs no gate, so editing it never forces a new generation.
CONTROL_PATHS = (ACTIVATION_PATH, *GATE_CALLERS)


@dataclass(frozen=True)
class ControlFile:
    """One control file of the protected checkout: its path and the SHA-256 of its bytes, or
    ``None`` for a file the checkout does not have."""

    path: str
    sha256: str | None


@dataclass(frozen=True)
class BuildConfig:
    """A validated protected Build config with the exact bytes of everything it lists.

    ``data`` is the validated document (treat it as read-only), ``raw`` the file's bytes,
    ``files`` the import closure in the config's order, each with its configured hash, and
    ``control`` the state of every path of :data:`CONTROL_PATHS` in the same checkout."""

    data: dict[str, Any]
    raw: bytes
    sha256: str
    files: tuple[AdapterFile, ...]
    control: tuple[ControlFile, ...]


def _protected_file(root: Path, relative: str, *, max_bytes: int) -> bytes:
    """Bytes of one regular file of the protected checkout, reached without crossing a symlink."""

    current = root
    try:
        for part in relative.split("/"):
            current = current / part
            if stat.S_ISLNK(current.lstat().st_mode):
                raise BuildConfigError(f"protected source crosses a symlink: {relative}")
    except OSError as exc:
        raise BuildConfigError(f"protected source is missing: {relative} ({exc.strerror or exc})") from exc
    return read_regular_file(current, label=relative, max_bytes=max_bytes, allow_empty=True)


def _control_file(root: Path, relative: str) -> ControlFile:
    """The state of one control file of the protected checkout. A missing file is a state of its
    own (a mode manages only some callers); what exists must be a regular file, reached without
    crossing a symlink, within the size of a workflow."""

    return protected_file_state(root, relative, max_bytes=lim.MAX_WORKFLOW_FILE_BYTES)


def protected_file_state(root: Path, relative: str, *, max_bytes: int) -> ControlFile:
    """The state of one file of the protected checkout ``root``: the SHA-256 of its bytes, or
    ``None`` when the checkout does not have it. What exists must be a regular file of at most
    ``max_bytes``, reached without crossing a symlink."""

    current = Path(root)
    try:
        for part in relative.split("/"):
            current = current / part
            if stat.S_ISLNK(current.lstat().st_mode):
                raise BuildConfigError(f"protected source crosses a symlink: {relative}")
    except (FileNotFoundError, NotADirectoryError):
        return ControlFile(relative, None)
    except OSError as exc:
        raise BuildConfigError(f"protected source cannot be read: {relative} ({exc.strerror or exc})") from exc
    data = read_regular_file(current, label=relative, max_bytes=max_bytes, allow_empty=True)
    return ControlFile(relative, sha256_hex(data))


def load_build_config(repo_root: Path, *, repository: str) -> BuildConfig:
    """Read the protected Build config of ``repository`` and its complete adapter closure.

    ``repo_root`` is the protected mod checkout. Every listed source must be a regular file whose
    SHA-256 is the configured one; sizes are bounded per file and for the whole closure. The
    control files of the same checkout are recorded as they are, present or not."""

    root = Path(repo_root)
    raw = _protected_file(root, BUILD_CONFIG_PATH, max_bytes=lim.MAX_CI_CONFIG_BYTES)
    document = validate_build_config(loads(raw, label=BUILD_CONFIG_PATH, max_bytes=lim.MAX_CI_CONFIG_BYTES))
    if document["repository"] != repository:
        raise BuildConfigError("protected Build config names another repository")
    total = len(raw)
    files = []
    for entry in document["adapter"]["files"]:
        data = _protected_file(root, entry["path"], max_bytes=lim.MAX_CI_ADAPTER_FILE_BYTES)
        total += len(data)
        if total > lim.MAX_CI_ADAPTER_TREE_BYTES:
            raise BuildConfigError("protected adapter closure exceeds its whole-byte cap")
        if sha256_hex(data) != entry["sha256"]:
            raise BuildConfigError(f"protected source differs from its configured hash: {entry['path']}")
        files.append(AdapterFile(entry["path"], entry["sha256"], data))
    control = tuple(_control_file(root, path) for path in CONTROL_PATHS)
    return BuildConfig(document, raw, sha256_hex(raw), tuple(files), control)
