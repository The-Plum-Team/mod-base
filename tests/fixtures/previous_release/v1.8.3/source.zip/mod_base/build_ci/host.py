"""Host filesystem fence for the initial GitHub-hosted Linux worker profile (MB11).

Explicit protected inputs only. Two fences exist. The runner closes its own home, which hides the
workspace, action and temp trees. Root then closes the image itself (``fence_worker_host``): a
hosted ``ubuntu-24.04`` image ships its tool cache, ``/usr/share``, ``/usr/local`` and the JDKs
world-writable, so any local account could replace the interpreter, a JDK or a command on root's
PATH. Neither fence is a VM boundary.
"""

from __future__ import annotations

import json
import os
import re
import selectors
import stat
import subprocess
import sys
import time
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

from mod_base.build_ci.worker import (WORKER_ACCOUNTS, WORKER_ROOT, WorkerAccount, WorkerError, WorkerResult,
                                      execute_worker, terminate_worker)
from mod_base.errors import MbError, single_line
from mod_base.model import limits


HOST_RUNNER_HOME = "/home/runner"
#: The trees a hosted ``ubuntu-24.04`` image leaves writable by everyone (measured on a runner):
#: the tool cache and the rest of ``/opt``, ``/usr/share``, ``/usr/local`` (the head of root's PATH),
#: the JDKs and one gem. A tree an image does not have is skipped.
HOST_FENCE_TREES = ("/opt", "/usr/share", "/usr/local", "/usr/lib/jvm", "/var/lib/gems")
# These image SDKs are not inputs to the Python/JDK worker profile or the runner's later
# checkout/upload actions. Keep Python, JDKs, Node, Git and their runtime/configuration trees
# accessible; close only these known unused SDK roots, without changing their existing owner.
# Neither is the Docker data root, which only the root daemon uses. Docker leaves it 0710
# root:root, so the proof entered it, and the layers of the images the image build pulls keep the
# modes those images chose (``ubuntu-24.04`` 20261018.339 pulled one with a world-writable
# ``/var/lib/pebble/default``). Closing the root ends that drift without changing a layer.
_DOCKER_DATA_ROOT = "/var/lib/docker"
_UNUSED_IMAGE_TREES = ("/opt/hostedtoolcache/CodeQL", "/usr/local/lib/android",
                       "/usr/share/dotnet", "/usr/share/swift", _DOCKER_DATA_ROOT)
# Closed trees whose owner opens them to everyone's search again: every start of the Docker daemon
# sets its data root to 0711 before 0710 (moby ``setupDaemonRoot``). What that moment exposes stays
# under the proof (``_closed_tree_entries``); Docker's own 0710 directories, such as the layers'
# ``overlay2``, keep everything below them out of it.
_REOPENED_IMAGE_TREES = (_DOCKER_DATA_ROOT,)
_FENCE_ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}
# What the proof refuses: a world-writable non-sticky directory, a world-writable regular file, or
# a group-writable regular file with another link (``_reachable_writable_entries``).
_WRITABLE_ENTRY = ("(", "-type", "d", "-perm", "-0002", "!", "-perm", "-1000", "-o",
                   "-type", "f", "-perm", "-0002", "-o", "-type", "f", "-perm", "-0020", "-links", "+1", ")")


@dataclass(frozen=True)
class HostBoundary:
    home: str
    uid: int
    gid: int
    device: int
    inode: int
    original_mode: int


def _canonical_path(value: str) -> PurePosixPath:
    if type(value) is not str or len(value) > limits.MAX_CI_TOOL_PATH_BYTES:
        raise WorkerError("host layout path exceeds its byte cap or has an invalid type")
    try:
        if len(value.encode("utf-8")) > limits.MAX_CI_TOOL_PATH_BYTES:
            raise WorkerError("host layout path exceeds its byte cap")
    except UnicodeError as error:
        raise WorkerError("host layout path is not strict UTF-8") from error
    if (not value.startswith("/") or "\\" in value or ":" in value
            or any(ord(character) < 32 or ord(character) == 127 for character in value)
            or any(part in {"", ".", ".."} for part in value.split("/")[1:])):
        raise WorkerError("host layout must use canonical absolute POSIX paths")
    return PurePosixPath(value)


def _open_directory(parts: tuple[str, ...], *, root: int | None = None) -> int:
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
    descriptor = os.open("/", flags) if root is None else os.dup(root)
    try:
        for part in parts:
            before = os.stat(part, dir_fd=descriptor, follow_symlinks=False)
            if not stat.S_ISDIR(before.st_mode):
                raise WorkerError("host layout contains a non-directory or symlink")
            child = os.open(part, flags, dir_fd=descriptor)
            try:
                opened = os.fstat(child)
                if (not stat.S_ISDIR(opened.st_mode)
                        or (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)):
                    raise WorkerError("host directory changed while opened")
            except BaseException:
                os.close(child)
                raise
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _open_runner_home(runner_environment: str, runner_home: str, workspace: str,
                      runner_temp: str) -> tuple[int, os.stat_result]:
    """Authenticate the initial hosted layout; return a descriptor of the runner home and its metadata.

    Every later check of a receipt compares the home's group with the runner's passwd group and
    with the group of what the runner creates. They are required to agree here, by name, so that a
    host where they differ is refused before anything is changed.
    """

    if (sys.platform != "linux" or type(runner_environment) is not str
            or runner_environment != "github-hosted" or runner_home != HOST_RUNNER_HOME):
        raise WorkerError("host fence requires the initial GitHub-hosted Linux layout")
    home = _canonical_path(runner_home)
    paths = (_canonical_path(workspace), _canonical_path(runner_temp))
    for path in paths:
        if home not in path.parents:
            raise WorkerError("host workspace and temp must be below the runner home")
    if paths[0] == paths[1]:
        raise WorkerError("host workspace and temp must be distinct directories")
    if os.getuid() == 0 or os.getgid() == 0:
        raise WorkerError("host fence requires a non-root runner identity")
    import pwd

    descriptor = None
    try:
        account = pwd.getpwuid(os.getuid())
        if account.pw_dir != HOST_RUNNER_HOME:
            raise WorkerError("runner passwd home does not bind the admitted layout")
        descriptor = _open_directory(tuple(home.parts[1:]))
        before = os.fstat(descriptor)
        if before.st_uid != os.getuid():
            raise WorkerError("runner home is not owned by the executing runner")
        if not before.st_gid == account.pw_gid == os.getgid():
            raise WorkerError("runner home group, the runner's passwd group and its process group differ")
        for path in paths:
            child = _open_directory(tuple(path.relative_to(home).parts), root=descriptor)
            try:
                if os.fstat(child).st_uid != os.getuid():
                    raise WorkerError("host workspace/temp is not runner-owned")
            finally:
                os.close(child)
        return descriptor, before
    except BaseException as error:
        if descriptor is not None:
            os.close(descriptor)
        if isinstance(error, (OSError, KeyError)):
            raise WorkerError("cannot establish private runner host fence") from error
        raise


def inspect_worker_host(*, runner_environment: str, runner_home: str,
                        workspace: str, runner_temp: str) -> HostBoundary:
    """The receipt :func:`protect_worker_host` will return, without changing the home.

    ``ci worker-prepare`` records it before it changes anything, so that ``ci worker-finish`` can
    restore the home whatever happens in between.
    """

    descriptor, before = _open_runner_home(runner_environment, runner_home, workspace, runner_temp)
    os.close(descriptor)
    return HostBoundary(HOST_RUNNER_HOME, before.st_uid, before.st_gid, before.st_dev,
                        before.st_ino, stat.S_IMODE(before.st_mode))


def protect_worker_host(*, runner_environment: str, runner_home: str,
                        workspace: str, runner_temp: str) -> HostBoundary:
    """Close traversal into the fixed runner home after authenticating the initial host layout.

    Call only from the protected prologue on a fresh admitted hosted runner, before candidate
    execution. Candidate processes must start with a private cwd and no inherited host fds.
    Toolchains outside the home remain accessible and must independently be protected against
    worker writes/import poisoning; caches are copied before worker admission.
    Failure after chmod deliberately leaves the home private. Never relax it while UIDs live.
    """

    descriptor, before = _open_runner_home(runner_environment, runner_home, workspace, runner_temp)
    try:
        os.fchmod(descriptor, 0o700)
        os.fsync(descriptor)
        after = os.fstat(descriptor)
        if ((after.st_dev, after.st_ino, after.st_uid, after.st_gid) !=
                (before.st_dev, before.st_ino, before.st_uid, before.st_gid)
                or stat.S_IMODE(after.st_mode) != 0o700):
            raise WorkerError("runner home did not bind the private host fence")
        return HostBoundary(HOST_RUNNER_HOME, after.st_uid, after.st_gid, after.st_dev,
                            after.st_ino, stat.S_IMODE(before.st_mode))
    except OSError as error:
        raise WorkerError("cannot establish private runner host fence") from error
    finally:
        os.close(descriptor)


def restore_worker_host(boundary: HostBoundary) -> None:
    """Give the runner home the mode it had before the fence: the last act of a job.

    Only once no worker account can run any more: both terminated and locked. The home must be
    the recorded directory of the executing runner, still closed or already restored (a second
    call changes nothing).
    """

    _validate_host_receipt(boundary)
    if os.getgid() == 0 or boundary.uid != os.getuid():
        raise WorkerError("host fence belongs to a different runner")
    descriptor = None
    try:
        descriptor = _open_directory(("home", "runner"))
        info = os.fstat(descriptor)
        if ((info.st_dev, info.st_ino, info.st_uid, info.st_gid) !=
                (boundary.device, boundary.inode, boundary.uid, boundary.gid)
                or stat.S_IMODE(info.st_mode) not in {0o700, boundary.original_mode}):
            raise WorkerError("runner home is not the fenced directory this job recorded")
        os.fchmod(descriptor, boundary.original_mode)
        os.fsync(descriptor)
        if stat.S_IMODE(os.fstat(descriptor).st_mode) != boundary.original_mode:
            raise WorkerError("runner home did not take its original mode back")
    except OSError as error:
        raise WorkerError("cannot restore the runner home") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _validate_host_receipt(boundary: HostBoundary) -> None:
    if sys.platform != "linux" or type(boundary) is not HostBoundary or boundary.home != HOST_RUNNER_HOME:
        raise WorkerError("host fence receipt is invalid or unsupported")
    if (any(type(value) is not int or value < 0 for value in
            (boundary.uid, boundary.gid, boundary.device, boundary.inode, boundary.original_mode))
            or boundary.original_mode > 0o7777):
        raise WorkerError("host fence receipt has invalid operating-system identity fields")
    if not 1 <= boundary.uid <= limits.MAX_CI_UNIX_ID or not 1 <= boundary.gid <= limits.MAX_CI_UNIX_ID:
        raise WorkerError("host fence must bind a nonprivileged runner identity")


def _authenticate_home_receipt(boundary: HostBoundary) -> None:
    descriptor = None
    try:
        descriptor = _open_directory(("home", "runner"))
        info = os.fstat(descriptor)
        if ((info.st_dev, info.st_ino, info.st_uid, info.st_gid) !=
                (boundary.device, boundary.inode, boundary.uid, boundary.gid)
                or stat.S_IMODE(info.st_mode) != 0o700):
            raise WorkerError("runner host fence identity or private mode changed")
    except OSError as error:
        raise WorkerError("cannot authenticate private runner host fence") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


def authenticate_host_boundary(boundary: HostBoundary) -> None:
    """Recheck the exact private runner-home inode before admitting either disposable UID."""

    _validate_host_receipt(boundary)
    if os.getgid() == 0 or boundary.uid != os.getuid():
        raise WorkerError("host fence belongs to a different runner")
    _authenticate_home_receipt(boundary)


def privileged_runner_identity() -> tuple[int, int]:
    """Root-only: the passwd identity that owns the fixed runner home, derived from the host.

    A root operation learns who the runner is from the filesystem and passwd, never from its
    request. The result names an account; it is not a host fence receipt.
    """

    if sys.platform != "linux" or os.getuid() != 0 or os.geteuid() != 0 or os.getgid() != 0:
        raise WorkerError("runner identity lookup requires protected root setup")
    import pwd

    descriptor = None
    try:
        descriptor = _open_directory(("home", "runner"))
        info = os.fstat(descriptor)
        account = pwd.getpwuid(info.st_uid)
        if ((account.pw_uid, account.pw_gid, account.pw_dir) != (info.st_uid, info.st_gid, HOST_RUNNER_HOME)
                or not 1 <= info.st_uid <= limits.MAX_CI_UNIX_ID or not 1 <= info.st_gid <= limits.MAX_CI_UNIX_ID):
            raise WorkerError("runner home does not belong to one nonprivileged passwd identity")
        return info.st_uid, info.st_gid
    except (OSError, KeyError) as error:
        raise WorkerError("cannot derive the runner identity from the fixed home") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


def authenticate_privileged_host_boundary(boundary: HostBoundary) -> None:
    """Bind the existing runner fence from protected root setup without granting worker authority."""

    _validate_host_receipt(boundary)
    if os.getuid() != 0 or os.geteuid() != 0 or os.getgid() != 0:
        raise WorkerError("privileged host recheck requires protected root setup")
    import pwd
    try:
        account = pwd.getpwuid(boundary.uid)
        if (account.pw_uid, account.pw_gid, account.pw_dir) != (boundary.uid, boundary.gid, boundary.home):
            raise WorkerError("privileged host recheck has a changed runner passwd identity")
    except (OSError, KeyError) as error:
        raise WorkerError("cannot bind runner passwd identity from root setup") from error
    _authenticate_home_receipt(boundary)


def _fence_command(command: tuple[str, ...], *, phase: str = "administrative",
                   deadline: float | None = None) -> tuple[bytes, bool]:
    """Run one fixed administrative command; return its bounded stdout and whether all of it fit.

    A command that cannot start, exits non-zero or outlives its bound is a rejection. A non-zero
    exit carries the start of what the command, or a program it ran, wrote to stderr. Every
    failure names the fixed phase and its elapsed time, without printing the command arguments.
    """

    process = None
    output, diagnostic = bytearray(), bytearray()
    complete = True
    started = time.monotonic()

    def failure(message: str) -> WorkerError:
        return WorkerError(f"host fence command {message} "
                           f"(phase={phase}; elapsed={time.monotonic() - started:.2f}s)")

    try:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, env=dict(_FENCE_ENV), cwd="/", close_fds=True)
        if process.stdout is None or process.stderr is None:
            raise failure("pipes unavailable")
        if deadline is None:
            deadline = time.monotonic() + limits.CI_HOST_FENCE_TIMEOUT_SECONDS
        with selectors.DefaultSelector() as selector:
            for stream, kept in ((process.stdout, output), (process.stderr, diagnostic)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream, selectors.EVENT_READ, kept)
            while selector.get_map():
                remaining = deadline - time.monotonic()
                ready = selector.select(remaining) if remaining > 0 else []
                if not ready:
                    raise failure("timed out")
                for key, _ in ready:
                    chunk = os.read(key.fd, limits.CI_PROCESS_READ_BYTES)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    # Keep the first bounded bytes of each stream and keep draining both.
                    room = limits.MAX_CI_HOST_FENCE_REPORT_BYTES - len(key.data)
                    key.data.extend(chunk[:room])
                    complete = complete and (key.data is diagnostic or len(chunk) <= room)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise failure("timed out")
        if process.wait(timeout=remaining) != 0:
            raise failure("failed: " + single_line(diagnostic.decode("utf-8", "replace"), limit=300))
        return bytes(output), complete
    except (OSError, subprocess.SubprocessError) as error:
        raise failure("could not complete") from error
    finally:
        if process is not None:
            try:
                if process.poll() is None:
                    process.kill()
                process.wait(timeout=limits.CI_TERMINATION_GRACE_SECONDS)
            except (OSError, subprocess.SubprocessError) as error:
                raise failure("did not reap") from error
            finally:
                for stream in (process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()


@dataclass(frozen=True)
class _Mount:
    device: str
    root: PurePosixPath
    point: PurePosixPath
    writable: bool


def _mount_path(value: str) -> PurePosixPath:
    escapes = {"\\040": " ", "\\011": "\t", "\\012": "\n", "\\134": "\\"}
    if "\\" in re.sub(r"\\(?:040|011|012|134)", "", value):
        raise WorkerError("host mount table has an unsupported path escape")
    value = re.sub(r"\\(?:040|011|012|134)", lambda match: escapes[match.group()], value)
    if (not value.startswith("/") or value.startswith("//") or "\0" in value
            or any(part in {".", ".."} for part in value.split("/"))):
        raise WorkerError("host mount table has a noncanonical path")
    return PurePosixPath(value)


def _parse_mounts(raw: bytes) -> tuple[_Mount, ...]:
    if not raw or len(raw) > limits.MAX_CI_HOST_MOUNTINFO_BYTES or not raw.endswith(b"\n"):
        raise WorkerError("host mount table is incomplete or exceeds its byte cap")
    try:
        text = raw.decode("utf-8", "strict")
    except UnicodeError as error:
        raise WorkerError("host mount table is not strict UTF-8") from error
    mounts = []
    for line in text.splitlines():
        fields = line.split(" ")
        separator = fields.index("-") if "-" in fields else 0
        if (separator < 6 or len(fields) != separator + 4 or any(not field for field in fields)
                or not fields[0].isascii() or not fields[0].isdigit()
                or not fields[1].isascii() or not fields[1].isdigit()
                or re.fullmatch(r"(?:0|[1-9][0-9]*):(?:0|[1-9][0-9]*)", fields[2]) is None):
            raise WorkerError("host mount table has an unsupported record")
        options = set(fields[5].split(","))
        if len(options & {"rw", "ro"}) != 1:
            raise WorkerError("host mount table has unsupported access options")
        mounts.append(_Mount(fields[2], _mount_path(fields[3]), _mount_path(fields[4]), "rw" in options))
    return tuple(mounts)


def _host_mounts() -> tuple[_Mount, ...]:
    with open("/proc/self/mountinfo", "rb") as stream:
        return _parse_mounts(stream.read(limits.MAX_CI_HOST_MOUNTINFO_BYTES + 1))


def _admit_closed_tree_mounts(tree: str, device: int, mounts: tuple[_Mount, ...]) -> bool:
    path = PurePosixPath(tree)
    parents = [mount for mount in mounts if mount.point == path or mount.point in path.parents]
    if not parents:
        raise WorkerError("unused image tree has no containing mount")
    longest = max(len(mount.point.parts) for mount in parents)
    parents = [mount for mount in parents if len(mount.point.parts) == longest]
    if len(parents) != 1 or parents[0].device != f"{os.major(device)}:{os.minor(device)}":
        raise WorkerError("unused image tree has an ambiguous or changed mount")
    containing = parents[0]
    root = containing.root / path.relative_to(containing.point)
    prune = True
    for mount in mounts:
        if (mount.device != containing.device or not mount.writable
                or mount.point == path or path in mount.point.parents):
            continue
        if root in mount.root.parents:
            raise WorkerError("unused image tree has a writable descendant mount alias outside its closure")
        if mount.root != root and mount.root not in root.parents:
            # An unrelated filesystem path can name a hard link to an inode of the tree. Its bind
            # alias may sit below another filesystem, outside the root proof's -xdev traversal.
            # Repair or prove the whole tree instead of assuming that inode unrelated.
            prune = False
    return prune


def _close_unused_image_tree(tree: str, *, mounts: tuple[_Mount, ...] | None = None) -> bool:
    """Close one real unused image directory to future accounts, preserving its existing owner's access.

    Returns whether its mount aliases were admitted, so that nothing below it needs repair or proof.
    """
    import pwd

    descriptor = _open_directory(tuple(PurePosixPath(tree).parts[1:]))
    try:
        before = os.fstat(descriptor)
        try:
            pwd.getpwuid(before.st_uid)
        except KeyError as error:
            raise WorkerError("unused image tree has no existing owner; cannot prove it closed") from error
        prune = _admit_closed_tree_mounts(tree, before.st_dev, _host_mounts() if mounts is None else mounts)
        if stat.S_IMODE(before.st_mode) != 0o700:
            os.fchmod(descriptor, 0o700)
            os.fsync(descriptor)
        after = os.fstat(descriptor)
        if ((after.st_dev, after.st_ino, after.st_uid, after.st_gid) !=
                (before.st_dev, before.st_ino, before.st_uid, before.st_gid)
                or not stat.S_ISDIR(after.st_mode) or stat.S_IMODE(after.st_mode) != 0o700):
            raise WorkerError("unused image tree did not bind its closed directory")
        return prune
    finally:
        os.close(descriptor)


def _close_writable_trees(trees: tuple[str, ...], *, closed_trees: tuple[str, ...] = (),
                          timings: dict[str, float] | None = None) -> None:
    """One walk: drop group/other write and default ACLs outside explicitly admitted closed trees.

    Only entries that carry a write bit are changed, so a second run leaves metadata alone. Links
    are never followed or changed, and the walk stays on each tree's own filesystem. Only the
    closed roots whose closure and mount aliases were admitted may be skipped. Other private
    directories retain their original complete repair, including aliases of their contents.
    """

    deadline = time.monotonic() + limits.CI_HOST_FENCE_TIMEOUT_SECONDS
    for tree in trees:
        started = time.monotonic()
        try:
            pruning = tuple(argument for closed in closed_trees
                            for argument in ("-path", closed, "-prune", "-o"))
            _fence_command(("/usr/bin/find", tree, "-xdev", "-ignore_readdir_race",
                            *pruning, "(",
                            "(", "(", "-type", "d", "-o", "-type", "f", ")", "-perm", "/0022",
                            "-exec", "/usr/bin/chmod", "go-w", "--", "{}", "+", ")", ",",
                            "(", "-type", "d", "-exec", "/usr/bin/setfacl", "-k", "--", "{}", "+", ")", ")"),
                           phase="repair", deadline=deadline)
        finally:
            if timings is not None:
                timings[tree] = round(time.monotonic() - started, 6)


def _repair_reaches(tree: str, repair_trees: tuple[str, ...]) -> bool:
    """Whether the ``find -xdev`` walk of one of ``repair_trees`` reaches the directory ``tree``.

    It does when a repair tree contains it and every directory from that tree down to it is on
    the repair tree's own filesystem; ``find -xdev`` enters no other.
    """

    path = PurePosixPath(tree)
    for root in map(PurePosixPath, repair_trees):
        if root not in path.parents:
            continue
        device = os.stat(root, follow_symlinks=False).st_dev
        current = root
        for part in path.relative_to(root).parts:
            current = current / part
            if os.stat(current, follow_symlinks=False).st_dev != device:
                break
        else:
            return True
    return False


def _listed_entries(output: bytes, device: int) -> list[str]:
    """The ``%D %p\\0`` records of a bounded listing that lie on ``device``."""

    expected = str(device).encode("ascii")
    entries = []
    for record in output.split(b"\0")[:-1]:  # A cut-off last record has no terminator and is dropped.
        number, _, path = record.partition(b" ")
        if number == expected:  # A mount point is listed with the device of what is mounted on it.
            entries.append(path.decode("utf-8", "backslashreplace"))
    return entries


def _reachable_writable_entries(root: str, *, skip: str,
                                deadline: float | None = None) -> tuple[list[str], bool]:
    """Reachable world-writable entries or group-writable hard links on ``root``'s filesystem.

    ``skip`` (the worker boundary) is not entered. Neither is a directory that only its owner can
    search when that owner is an existing account: an account created later can never be that
    owner, so nothing below is reachable for it. Sticky directories are entered but not reported.
    A group-writable hard link can alias an inode of a closed tree; its group-mode ACL mask can grant
    a future numeric UID/GID write even when its owning group already exists. Reject it without
    guessing future IDs or parsing access ACLs. Returns entries and listing completeness.
    """

    device = os.stat(root, follow_symlinks=False).st_dev
    output, complete = _fence_command((
        "/usr/bin/find", root, "-xdev", "-ignore_readdir_race", "-path", skip, "-prune", "-o",
        "(", "-type", "d", "!", "-perm", "/0011", "!", "-nouser", "-prune", ")", "-o",
        "(", *_WRITABLE_ENTRY, "-printf", "%D %p\\0", ")"), phase="verification", deadline=deadline)
    return _listed_entries(output, device), complete


def _closed_tree_entries(tree: str, *, whole: bool, deadline: float | None = None) -> tuple[list[str], bool]:
    """What a later account could still reach below a closed tree, which the proof skips.

    ``whole``: the tree's mount aliases were not admitted and no repair walk reaches it, so an
    unrelated same-device mount may name a hard link to one of its regular files from below
    another filesystem. List every group- or world-writable regular file with more than one link,
    private directories included. Nothing else below the closed root has another path: a
    directory has no hard link and a descendant mount alias was refused.

    Otherwise the tree's owner reopens it to search by everyone (``_REOPENED_IMAGE_TREES``). List
    what the proof would list below it, pruning only the directories that no later account could
    search even then by their mode: not searchable by others, nor by an owner or group that does
    not exist yet. Unlike the proof's pruning, which holds under ACLs because a directory's group
    bits are its mask, this one reads modes only: a named ACL entry of a group-searchable
    directory is not considered (Docker sets none). Returns entries and listing completeness.
    """

    device = os.stat(tree, follow_symlinks=False).st_dev
    if whole:
        expression = ("-type", "f", "-links", "+1", "-perm", "/0022", "-printf", "%D %p\\0")
    else:
        expression = ("(", "-type", "d", "!", "-perm", "-0001", "!", "(", "-nouser", "-perm", "-0100", ")",
                      "!", "(", "-nogroup", "-perm", "-0010", ")", "-prune", ")", "-o",
                      "(", *_WRITABLE_ENTRY, "-printf", "%D %p\\0", ")")
    output, complete = _fence_command(("/usr/bin/find", tree, "-xdev", "-ignore_readdir_race", "-mindepth", "1",
                                       *expression), phase="verification", deadline=deadline)
    return _listed_entries(output, device), complete


def fence_worker_host(*, boundary: HostBoundary) -> None:
    """Root-only, before any worker account exists: close the hosted image to later accounts.

    Closes unused image SDKs and the Docker data root at their existing owner, removes group/other
    write permission and default ACLs from reachable ``HOST_FENCE_TREES``, then proves that no
    world-writable non-sticky directory, world-writable regular file or group-writable hard-link
    alias remains reachable outside the worker boundary. It also proves what the closures cannot
    hide: the writable hard links of a closed tree whose mount aliases were not admitted and that
    no repair walk reaches, and what a reopened tree exposes. Anything left is a failure, as is an
    unprovable closure or a command that fails. Nothing below a closed tree is changed except by
    the repair of a tree containing it. Sticky directories outside those trees, such as ``/tmp``,
    stay as they are.
    """

    started = time.monotonic()
    timings: dict[str, Any] = {"mounts": 0.0, "closure": {}, "walked_closed": [], "repair": {},
                               "verification": 0.0, "closed_verification": {}, "ok": False}
    try:
        _fence_worker_host(boundary, timings)
        timings["ok"] = True
    finally:
        timings["total"] = round(time.monotonic() - started, 6)
        # A bounded informational observation, not an admission receipt. The runner transports
        # it as an audit event; hosted tests report the first real fence even when CLI output is
        # captured. Fixed phase names and image roots never expose candidate-controlled paths.
        print("mod-base host-fence timing: " + json.dumps(timings, separators=(",", ":")),
              file=sys.stderr, flush=True)


def _fence_worker_host(boundary: HostBoundary, timings: dict[str, Any]) -> None:
    authenticate_privileged_host_boundary(boundary)
    import pwd

    try:
        for name in WORKER_ACCOUNTS.values():
            try:
                pwd.getpwnam(name)
            except KeyError:
                continue
            raise WorkerError("host fence must run before any worker account exists")
        started = time.monotonic()
        try:
            mounts = _host_mounts()
        finally:
            timings["mounts"] = round(time.monotonic() - started, 6)
        present, closed_trees, unadmitted = [], [], []
        for tree in _UNUSED_IMAGE_TREES:
            started = time.monotonic()
            try:
                admitted = _close_unused_image_tree(tree, mounts=mounts)
            except FileNotFoundError:
                continue
            finally:
                timings["closure"][tree] = round(time.monotonic() - started, 6)
            present.append(tree)
            (closed_trees if admitted else unadmitted).append(tree)
        timings["walked_closed"].extend(unadmitted)
        trees = []
        for tree in HOST_FENCE_TREES:
            try:
                os.close(_open_directory(tuple(PurePosixPath(tree).parts[1:])))
            except FileNotFoundError:
                continue
            trees.append(tree)
        # A closed tree whose aliases were not admitted keeps the complete repair of the tree that
        # contains it. One that no repair walk reaches (the Docker data root, or an SDK on a
        # filesystem of its own) is proved whole instead: its contents are not the fence's to
        # change, and changing image layers would break the images.
        proved_whole = tuple(tree for tree in unadmitted if not _repair_reaches(tree, tuple(trees)))
        if trees:
            _close_writable_trees(tuple(trees), closed_trees=tuple(closed_trees), timings=timings["repair"])
        started = time.monotonic()
        deadline = started + limits.CI_HOST_FENCE_TIMEOUT_SECONDS
        try:
            entries, complete = _reachable_writable_entries("/", skip=str(WORKER_ROOT.parent), deadline=deadline)
        finally:
            timings["verification"] = round(time.monotonic() - started, 6)
        for tree in present:
            walks = (True,) * (tree in proved_whole) + (False,) * (tree in _REOPENED_IMAGE_TREES)
            if not walks:
                continue
            started = time.monotonic()
            try:
                for whole in walks:
                    found, fits = _closed_tree_entries(tree, whole=whole, deadline=deadline)
                    entries.extend(found)
                    complete = complete and fits
            finally:
                timings["closed_verification"][tree] = round(time.monotonic() - started, 6)
    except OSError as error:
        raise WorkerError("cannot fence the worker host") from error
    if entries or not complete:
        first = repr(entries[0])[:300] if entries else "an unlisted entry"
        raise WorkerError(f"host fence left {len(entries)}{'' if complete else ' or more'} world-writable or "
                          "aliased group-writable "
                          f"entries reachable on the root filesystem, first {first}")
    authenticate_privileged_host_boundary(boundary)


def execute_isolated_worker(account: WorkerAccount, *, boundary: HostBoundary,
                            command: tuple[str, ...], python: str, java_home: str | None,
                            identity: dict[str, Any], run_id: int, run_attempt: int,
                            values: Mapping[str, str], timeout_seconds: int) -> WorkerResult:
    """Recheck the private host fence before dispatch; a failed fence locks the disposable UID.

    Authenticated source/import/caches and native validation remain caller preconditions. The
    worker's execution path uses a private cwd and closes inherited host descriptors.
    """

    try:
        authenticate_host_boundary(boundary)
    except MbError:
        terminate_worker(account)
        raise
    return execute_worker(account, command=command, python=python, java_home=java_home,
                          identity=identity, run_id=run_id, run_attempt=run_attempt,
                          values=values, timeout_seconds=timeout_seconds)
